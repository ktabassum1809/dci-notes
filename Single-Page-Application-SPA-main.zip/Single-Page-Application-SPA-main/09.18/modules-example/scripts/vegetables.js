export const veg1 = "lettuce"
export const veg2 = "cucumber"
export const veg3 = "zucchini"