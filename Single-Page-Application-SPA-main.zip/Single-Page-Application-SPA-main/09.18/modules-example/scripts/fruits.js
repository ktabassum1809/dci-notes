export const fruit1 = "apple"
export const fruit2 = "pear"
export const fruit3 = "banana"
export const fruit4 = "watermelon"