const bread = "bread"

export const cookies = "cookies"

export default bread