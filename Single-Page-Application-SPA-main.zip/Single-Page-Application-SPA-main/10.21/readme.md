# Route parameters:

### Exercises:

- [39-SPA-router-color-factory](https://classroom.github.com/a/W-1nN2HT)
- [40-SPA-router-dog-finder](https://classroom.github.com/a/7ZZNP8nK)