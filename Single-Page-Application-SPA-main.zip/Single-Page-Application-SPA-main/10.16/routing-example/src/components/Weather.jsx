export default function Weather() {
    return <p>I am the weather</p>
}
