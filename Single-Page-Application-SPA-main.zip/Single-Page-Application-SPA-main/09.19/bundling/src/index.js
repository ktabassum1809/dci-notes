let test = (x) => console.log(123,x); 
test(2);