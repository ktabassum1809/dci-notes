export default function UserRegistration() {
    return <p>Registration</p>
}