# Form refactoring

This exercise is a simulation of a coding challenge that a company might give when applying for a job.

In this repo you will find the file "old.html". Your task is to convert this form into a React SPA using Vite. Start by creating a vite project _inside_ this folder with `npm create vite@latest form-project`, but the rest is up to you!

Good luck, have fun!
