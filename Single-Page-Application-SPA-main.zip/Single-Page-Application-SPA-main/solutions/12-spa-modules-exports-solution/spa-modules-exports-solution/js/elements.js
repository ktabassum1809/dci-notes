const day = document.querySelector("#day");
const month = document.querySelector("#month");
const year = document.querySelector("#year");
const output = document.querySelector("#output");

export { day, month, year, output };
