import { init } from "./init.js";

// Initialize the elements
init();
