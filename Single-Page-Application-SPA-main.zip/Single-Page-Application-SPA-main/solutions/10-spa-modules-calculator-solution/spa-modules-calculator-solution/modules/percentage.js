function difference(first, second) {
  let calc = second - first;
  return (calc * 100) / first;
}

export { difference };
