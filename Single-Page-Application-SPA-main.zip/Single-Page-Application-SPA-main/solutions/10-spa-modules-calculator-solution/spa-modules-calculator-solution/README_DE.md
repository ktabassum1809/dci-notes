# Calc X

**Anweisungen**:
* Sieh dir die Startdateien in diesem Repository an. Du findest die Logik der Taschenrechner-App in `modules/percentage.js` und `modules/aspect-ratio.js`.
* Exportiere die Funktionen in die Operationsdateien.
* Importiere die Funktionen in `modules/index.js` und füge die Funktionen in der Datei `index.js` zur Benutzeroberfläche hinzu.
* Das Berechnungsergebnis sollte sich aktualisieren, während der Nutzer die Werte eingibt, daher werden keine Submit-Buttons benötigt.
* Vergiss nicht, die Datei `index.js` am Ende der Datei `index.html` einzufügen. Ändere nichts anderes in der Datei `index.html`.
