import "./Footer.css";

export default () => <footer>&copy; 1998 [Company]</footer>;
