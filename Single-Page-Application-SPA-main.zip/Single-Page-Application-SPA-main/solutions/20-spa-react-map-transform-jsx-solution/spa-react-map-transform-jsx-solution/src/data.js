export default [
    {"id":"01781160-0fd2-4efb-8b98-f559cb9a6181","name":"Badger, honey"},
    {"id":"2569a1a4-eb74-4169-b0c2-ca315433f4c4","name":"American alligator"},
    {"id":"f4096ee2-5cdf-4ffe-85d5-7c24f0ebe87d","name":"Scottish highland cow"},
    {"id":"04433690-7e4b-4e30-9306-c08767a92271","name":"Ring-tailed coatimundi"},
    {"id":"865270d5-c23b-4fcd-99d3-2ca6bdcbed79","name":"Raven, white-necked"},
    {"id":"ada41d57-7612-4cc5-b8c6-3c12bc371c05","name":"Asian false vampire bat"},
    {"id":"d546e6e8-c2a1-4bc5-b621-2164f3f0c5b2","name":"Jackal, golden"},
    {"id":"6b05e3bf-13f4-43ef-9db7-cba0f276c6a5","name":"Greater adjutant stork"},
    {"id":"309558f4-defe-402b-aaa5-89fe36634ee6","name":"Dove, little brown"},
    {"id":"21b5f2fd-be87-4de1-ad31-53849521224f","name":"Parrot, hawk-headed"},
    {"id":"02161198-41a6-42af-b131-cca625106d73","name":"African jacana"},
    {"id":"77806e87-a270-429a-be6b-5cd1aafb1e20","name":"Wallaroo, common"},
    {"id":"de03c59e-3bfa-478b-bdd9-bc4059576759","name":"Mongoose, javan gold-spotted"},
    {"id":"6dd4b259-f227-43b3-9d5e-92c222cf0d4f","name":"Southern black-backed gull"},
    {"id":"0c2f7ef2-112a-4ddd-afee-5cb205639ef3","name":"Skunk, western spotted"},
    {"id":"af1a8943-67f5-4974-beb0-0ebbe0ac346d","name":"Pademelon, red-legged"},
    {"id":"fc438963-7e02-42d4-a7ef-d9ad02e11547","name":"Oriental white-backed vulture"},
    {"id":"ee8c8d35-2ad3-4594-ae0c-1199fe92ce16","name":"American racer"},
    {"id":"1da44178-58d8-4d45-8e90-a02d12e83071","name":"Red-billed tropic bird"},
    {"id":"26310c98-c7f0-43c1-aaa0-50144ce0f4ed","name":"Red-shouldered glossy starling"},
    {"id":"a29576fc-1abc-455a-a99e-ee2993b06e66","name":"Four-horned antelope"},
    {"id":"3f1e8da2-7839-4bff-8678-3249c138f52d","name":"Common zorro"},
    {"id":"96495159-68bd-43e5-9786-96ffcf193848","name":"Grey heron"},
    {"id":"0ac0bf60-cb3e-46d2-881e-61b74abc9127","name":"Oryx, beisa"},
    {"id":"715ce666-a3c4-4bf1-8f26-1fd90bdc4ddd","name":"Heron, yellow-crowned night"},
    {"id":"bb7ef12f-b42c-41d5-a312-03b36c758e45","name":"Southern white-crowned shrike"},
    {"id":"42f363b7-abef-4aeb-ad12-283dff7ecc7b","name":"Oystercatcher, blackish"},
    {"id":"09774ef0-dbb9-4c3a-9ebe-ad4a269658be","name":"Hedgehog, south african"},
    {"id":"90022d77-bec2-472f-a55f-964c977651db","name":"Otter, canadian river"},
    {"id":"b3c59838-7580-476f-9a3c-e7c53b3fe839","name":"Capuchin, weeper"},
]/*



































































Hi :^)

This is a secret message!
Nice job finding it!
Here's a koala: 🐨

*/