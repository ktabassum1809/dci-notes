import RandomList from "./components/RandomList";

export default function App() {
  return (
    <div>
      <RandomList />
    </div>
  );
}
