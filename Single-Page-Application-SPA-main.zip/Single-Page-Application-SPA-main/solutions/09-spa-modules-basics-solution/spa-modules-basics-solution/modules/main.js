import { scrollWindow } from "/modules/scroll.js";
import { clickImages } from "/modules/click.js";
import { hoverHeader } from "/modules/hover.js";

scrollWindow();
clickImages();
hoverHeader();
