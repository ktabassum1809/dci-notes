import Room from "./Room.jsx"

function App() {
  return <Room />
}

export default App
