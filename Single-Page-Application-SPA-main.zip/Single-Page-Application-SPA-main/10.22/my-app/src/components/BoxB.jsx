import BoxC from "./BoxC";

export default function BoxB() {
  return (
    <div>
      BoxB
      <BoxC />
    </div>
  );
}
