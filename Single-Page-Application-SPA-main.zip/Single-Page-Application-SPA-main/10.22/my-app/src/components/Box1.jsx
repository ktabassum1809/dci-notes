import BoxA from "./BoxA";

export default function Box1() {
  return (
    <div>
      Box1
      <BoxA />
    </div>
  );
}
