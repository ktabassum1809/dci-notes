# State management: global state & react context

### Exercises:

- [41-SPA-Store-scoreboard](https://classroom.github.com/a/6GYVb1ee)
- [42-spa-store-useeffect-language](https://classroom.github.com/a/BXkJ63JA)
