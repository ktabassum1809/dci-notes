import { useState } from "react";

export default function Greeting() {
  return (
    <div>
      It's better to write the 'Greeting' component here in a separate file, you
      can consider it a homework for you when you get bored :D
    </div>
  );
}
