# SPA Module Overview
[Repo Link](https://github.com/dci-fbw-wd-24-e03/Single-Page-Application-SPA)

[Part 1]

## Working with Browser
- DOM: Querying, Manipulating, Traversing, EventListening...

## Modules
- Imports & Exports, NPM Workflow...

## Asynchronous Programming
- Promises, JSON, Fetch(), HTTP methods, CORS...

## Assessment & Exam

[Part 2]

## Working with ReactJS 

## Assessment & Exam

## SPA Final Project