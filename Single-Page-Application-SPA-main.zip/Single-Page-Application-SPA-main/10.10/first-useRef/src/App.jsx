import './App.css'
import MyComponent from "./components/MyComponent.jsx"

function App() {

  return (
    <>
      <MyComponent />
    </>
  )
}

export default App
