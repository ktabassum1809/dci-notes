# styling in react: CSS, SCSS, Bootstrap

## resources:

- [react-bootstrap](https://react-bootstrap.github.io/)

### Exercises:

- [30-SPA-component-state-credit-card](https://classroom.github.com/a/Oy8gKl6b)
- [31-SPA-components-state-lotto](https://classroom.github.com/a/ID1ziyAj)
- [32-SPA-components-customizable-avatar](https://classroom.github.com/a/DPDsXJzK)