import './App.css'
import ControlledInput from "./components/ControlledInput"

function App() {

  return (
    <>
      <ControlledInput />
    </>
  )
}

export default App
