import './App.css'
import Form from "./components/Form"

function App() {
  return (
    <main>
      <h1>Feedback form</h1>
      <Form />
    </main>
  )
}

export default App
