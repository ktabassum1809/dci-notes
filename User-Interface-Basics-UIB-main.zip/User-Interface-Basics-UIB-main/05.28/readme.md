# UIB - layout - 06: CSS Grid Items

**yesterday:**

- CSS Grid

**Today:**

- Grid Items taking multiple columns and rows
- naming grid columns and areas

## Exercises

- [49-UIB-layout-grid](https://classroom.github.com/a/YT7hbAcA)
- [50-UIB-layout-grid-blogger](https://classroom.github.com/a/8UZe_ff4)
- [51-UIB-layout-grid-meets-flexbox](https://classroom.github.com/a/0DA1PnMP)