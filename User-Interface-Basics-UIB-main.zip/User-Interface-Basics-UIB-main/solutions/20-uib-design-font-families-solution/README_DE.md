# Fabulous Fonts

**Anweisungen**:
* Wähle eine Schriftart aus Google Fonts für alle Überschriften auf der Seite. Die Schriftart muss eine `sans-serif` Schrift sein.
* Alle Elemente, die im Hauptelement verschachtelt sind, sollten eine andere `sans-serif` Schriftart haben. Biete einen Fallback im Font-Stack an.
* Das Absatzelement mit der Klasse `code` sollte eine `monospace` Schrift haben. Stelle ein Fallback im font-stack bereit.

![alt-text](/image/reference.png "Reference Image")
