# Grid trifft Flexbox

Verwende `grid-template-areas` und `flex` für die Navigationsleiste, um das folgende Referenzbild zu erstellen.

![reference](mockup.png)

- Gestalte die Seite mit `padding`, `gap`, verschiedenen Hintergrundfarben, verschiedenen Schriftfamilien usw.

Viel Glück und viel Spaß!
