# Mach deine Schriftarten fantastisch!

**Anleitung**:
* Füge ein Font-Awesome-Icon jeweils am Anfang und am Ende der h1-Überschrift hinzu.
* Zentriere und unterstreiche die h1-Überschrift.
* Zentriere das Element mit der Klasse `.review`. Gib diesem Element einen Textschatten und zeige den Text in Großbuchstaben an.
* Füge Icons am Anfang jedes `p` Elements hinzu, das in den Abschnitten (sections) mit der Klasse `.info` verschachtelt ist.
* Füge nach jeder Bewertungsoption ein passendes Icon hinzu.
* Lege eine Größe für die Icons auf der Seite fest.

![Referenzbild](images/reference-image-desktop.png "Referenzbild")