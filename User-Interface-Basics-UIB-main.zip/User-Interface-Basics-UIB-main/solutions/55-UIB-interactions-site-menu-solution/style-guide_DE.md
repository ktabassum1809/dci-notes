## Typografie

Schriftart: [Lobster](https://fonts.google.com/?query=lobster)
Basis: 20px

## Farben

### Primär

- #5366c3
- #3f83c0
- #2aa1bd
- #15bfbb

### Neutral

- #ffffff
- #dbe1e2
