# Site menu

Take a look at the example and try to recreate the effect.
1. Use anchor tags to create 4 or more menu items.
3. Give each link a unique `background-color`.
4. Utilize the `transition` and `transform` css properties to create a smooth transition on hover.

![example](mockups/site-menu-example.png)

![example hover](mockups/site-menu-hover-2-example.png)

![example](mockups/site-menu-example.gif)