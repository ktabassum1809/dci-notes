# Website-Menü

Sieh dir das Beispiel an und versuche, den Effekt nachzuahmen.

![Beispiel](mockups/site-menu-example.png)

![Beispiel hover](mockups/site-menu-hover-2-example.png)

![Beispiel](mockups/site-menu-example.gif)
