# Dateien verarbeiten

Erstelle eine Animation der Verarbeitungsdateien.

Verwende die angegebene HTML-Datei und die Symbole im Ordner `images`.

Bearbeitungsbeispiel:

![](./processing-example.gif)
