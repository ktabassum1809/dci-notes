# Processing files
Create a processing files animation. Start with the given html file and icons in the images folder.

Each image `div` container should have an `appear` animation, 

Looks like there are images included in the starting HTML, but if you try to open the website with a browser, the images don't work! Find and fix the issue.

Processing Example:

![](./processing-example.gif)