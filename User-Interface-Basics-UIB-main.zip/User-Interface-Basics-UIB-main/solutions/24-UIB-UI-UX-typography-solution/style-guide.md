## Colors

- Grey: #ffffff, #ffffff9f, #b3b0b0, #9b9b9b8f;
- Maroon: #f52f2f,#aa0e0e, #8a0f0f, #660000
- Blue: #2e21e7

## Fonts

The font weights used are 400, 500 and 600.

- root font: [IBM Plex Serif](https://fonts.google.com/specimen/IBM+Plex+Serif)
- h1 font: [Noto Serif](https://fonts.google.com/noto/specimen/Noto+Serif?category=Serif)
- h2 font: [Bitter](https://fonts.google.com/specimen/Bitter?category=Serif)
