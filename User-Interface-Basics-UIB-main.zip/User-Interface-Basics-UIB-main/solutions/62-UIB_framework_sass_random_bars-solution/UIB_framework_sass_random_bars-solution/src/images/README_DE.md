# Der Ordner `images`.

Lege hier alle Bilder ab, die du in dein HTML oder deine Stylesheets einbinden willst.
