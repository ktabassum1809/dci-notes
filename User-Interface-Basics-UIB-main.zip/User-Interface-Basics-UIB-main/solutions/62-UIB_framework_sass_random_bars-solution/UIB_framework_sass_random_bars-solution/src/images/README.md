# The `images` folder

Put any images you want to include in your HTML or stylesheets in here.
