# Grundlegende Datenübungen

## Übung: Tabelle 2

**Anweisungen**:

1.  Erstelle eine einfache HTML-Seite mit allen wichtigen Elementen.
2.  Sieh dir die Mockup-Datei an und erstelle die folgende Tabelle mit 3 Spalten.

| Unternehmen | Kontakt | Betrag |
| ---------------------------- | ---------------- | ------ |
| Alfreds Futterkiste | Maria Anders | 45 |
| Centro comercial Moctezuma | Francisco Chang | 45 |
| Ernst Handel | Roland Mendel | 45 |
| Island Trading | Helen Bennett | 45 |
| Laughing Bacchus Winecellars | Yoshi Tannamuri | 45 |
| Magazzini Alimentari Riuniti | Giovanni Rovelli | 45 |
| Total | | 210 |

3.  Style es mit Zebrastreifen, indem du Pseudo-Kind-Selektoren verwendest.
4.  Verwende KEINE veralteten HTML-Attribute. Style mit CSS.

!["mockup-image"](/image/mockup.png)