# Untertitel

Versuchen wir, die unten gezeigte Schwebeanimation (hover animation) nachzustellen:

![Beispiel](images/mockup.gif)

## Zielsetzung / Info

- Verwende die Eigenschaft `transition` für einen sanften Übergang.
- `relative`/`absolute` Positionierung und die Eigenschaft `overflow` können dabei nützlich sein.
- Versuche, dem Beispiel so nahe wie möglich zu kommen.
- Viel Spaß 🐱💻🐱🏍
