# Layout

## Colors

### Text

- Grey: #484848
- Yellow: #fff900
- Orange: #ff6c00

### Background

- Very Dark Grey: #262626;

## Typography

- Font size: 80px

### Fonts

- Family: [Lato](https://fonts.google.com/specimen/Lato)
