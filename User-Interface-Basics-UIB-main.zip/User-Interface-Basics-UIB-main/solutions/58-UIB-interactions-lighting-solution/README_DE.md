# Light Me Up

Versuchen wir, die unten gezeigte Lichtanimation nachzustellen:

![Beispiel](img/mockup.gif)

## Zielsetzung / Info

- Du musst `@keyframes` verwenden und eine eigene Animation erstellen.
- `text-shadow` und `animation-delay` können dafür nützlich sein.
- Beziehe dich auf den [Style Guide](style-guide.md) für Schriftarten, Farben usw...
- Versuche, dem Beispiel so nahe wie möglich zu kommen.
- Viel Spaß 🐱🚀
