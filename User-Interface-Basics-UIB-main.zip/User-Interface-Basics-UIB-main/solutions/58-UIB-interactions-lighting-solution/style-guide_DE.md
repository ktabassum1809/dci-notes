# Layout

## Farben

## Text

- Grau: #484848
- Gelb: #fff900
- Orange: #ff6c00

### Hintergrund

- Sehr dunkles Grau: #262626;

## Typografie

- Schriftgröße: 80px

## Schriftarten

- Familie: [Lato](https://fonts.google.com/specimen/Lato)
