# Grundlegende Datenübungen

## Formulare gestalten

**Anweisungen**:

1.  Erstelle eine einfache HTML-Seite mit allen wichtigen Elementen.
2.  Schau dir das Mockup-Bild an. Erstelle ein Formular und gestalte es wie das Mockup.
3.  Verwende die bereitgestellten Bilder im Ordner images.

![mockup-image](/images/reference-image.png)
