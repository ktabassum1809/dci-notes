# Strapping

**Instructions**:

* Work in the existing `index.html` file
* Create a simple page using bootstrap!
Use the mockup image as a guide.
* Your page must include the following bootstrap components: a banner, a navigation bar, a simple flex layout and cards!
* You shouldn't have to use _any_ CSS to make this page!
* Refer to bootstrap documentation for more info.


![mockup-image](/image/mockup.png)