# Umreifung

**Anweisungen**:

* Erstelle eine einfache Seite mit Bootstrap!
Verwende das Mockup-Bild als Anleitung.
* Deine Seite muss enthalten: ein Banner (banner), eine Navigationsleiste (navigation bar), ein einfaches Rastersystem (grid system) und Karten (cards)!
* Du solltest _kein_ CSS verwenden müssen, um diese Seite zu erstellen!
* Weitere Informationen findest du in der Bootstrap-Dokumentation.


![mockup-image](/image/mockup.png)
