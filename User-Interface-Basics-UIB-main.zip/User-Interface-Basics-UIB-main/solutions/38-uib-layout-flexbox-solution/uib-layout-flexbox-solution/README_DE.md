# Flex

**Anweisungen für jeden Ordner**:

* 01: Verwende Flexbox, um alle Divs in einer Reihe auszurichten. Verwende wrap, damit die Divs in mehreren Zeilen erscheinen. Zentriere die Zeilen im Container
* 02: Verwende flexbox, um die Divs in einer Reihe auszurichten. Kehr die Reihenfolge der Divs um.
* 03: Verwende Flexbox, um alle Divs in einer Spalte in umgekehrter Reihenfolge in der Mitte der Seite anzuzeigen.
* 04: Verwende Flexbox, um alle Divs in einer Reihe am unteren Rand des Containers anzuzeigen. Die Divs sollen nur eine Zeile einnehmen.
* 05: Verwende Flexbox, um die Divs in einer Zeile in der Mitte des Containers darzustellen.
* 06: Verwende Flexbox, um alle Divs in einer Spalte in der Mitte der Seite anzuzeigen.

**Hinweis**: Eine Anleitung findest du auch in der css-Datei für jede Übung.



