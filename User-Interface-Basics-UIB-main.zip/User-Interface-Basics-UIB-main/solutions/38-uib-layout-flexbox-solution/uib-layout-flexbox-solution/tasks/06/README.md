# Task 6

Modify the [main.css](./main.css) file and;

- Use flexbox to layout all `<div>` elements in a row
- Make all `<div>` elements appear at the bottom of the container
- Center the rows horizontally within the container
- The `<div>` elements should all appear on one line

## Reference Image

![Reference image](./reference.gif)
