# Task 4

Modify the [main.css](./main.css) file and;

- Use flexbox to display all `<div>` elements in one column
- Center the rows horizontally within the container

## Reference Image

![Reference image](./reference.gif)
