# Task 2

Modify the [main.css](./main.css) file and;

- Use flexbox to layout all `<div>` elements in a row, but in **reverse order**
- Center the rows horizontally within the container

## Reference Image

![Reference image](./reference.png)
