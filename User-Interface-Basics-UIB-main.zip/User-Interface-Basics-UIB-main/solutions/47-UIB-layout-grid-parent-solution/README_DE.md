# Sports Grid

**Anweisungen**:
* Verschachtle alle Sportbilder aus dem [Assets-Ordner](./assets) in das Hauptelement mit der Klasse `container`.

* Mache das Hauptelement zu einem Container mit drei gleich großen Spalten, die den gesamten verfügbaren Platz einnehmen.

* Füge eine Rasterlücke hinzu.
![grid1-mock](/assets/grid1-reference.png)

* Kommentiere die ursprüngliche Größe des Containers aus und füge die folgenden Größen zu den Spalten hinzu:
    - Spalte 1 - Mindestgröße: 100px, Maximalgröße: 350px
    - Spalte 2 - 1 Bruchteil
    - Spalte 3 - Mindestgröße: 100px, Maximalgröße 350px
![grid2-mock](/assets/grid2-reference.png)
