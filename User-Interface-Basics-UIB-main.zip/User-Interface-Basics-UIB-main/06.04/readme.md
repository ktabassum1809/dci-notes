# UIB - Advanced - Animation 2:

**Yesterday:**

- Animation with transition
- transform

**Today:**

- Animation with @keyframes

## Exercises

- [58-UIB-interactions-lighting](https://classroom.github.com/a/Ko-VmU9_)
- [59-UIB_interaction_animations_processing_files](https://classroom.github.com/a/ygl100wS)
- [60-UIB-interactions-animated-portfolio](https://classroom.github.com/a/N1KzxD6A)