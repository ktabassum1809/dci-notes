# Flexbox practice day

## last day:

- Flex items

## today:

- Recap
- Live-coding excercise 42-uib-layout-7-box-layout

### exercises

- Ex1: [44-UIB_layout_laying_out_fullpage](https://classroom.github.com/a/9YpM2stQ)
- Ex2: [45-UIB-layout-travel-destination-form](https://classroom.github.com/a/_AC2zQhr)
- Ex3: [46-UIB-layout-speaker-shop](https://classroom.github.com/a/JUL1dM71)
