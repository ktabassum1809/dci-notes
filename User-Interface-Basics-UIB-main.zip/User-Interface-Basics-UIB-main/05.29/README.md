# Grid, flexbox & position practice day

## last day:

- Grid on child elements

## today:

- New and previous exercises

### exercises

- Ex1: [52-UIB-layout-zoom-session](https://classroom.github.com/a/dStuvgN3)
- Ex2: [53-UIB-layout-freelance-position](https://classroom.github.com/a/1OcjQGc1)
- Ex3: [54-UIB-layout-customer-satisfaction-dashboard](https://classroom.github.com/a/rxdSeuSr)