// Converting to string with "String()"

const stringNum = String(-5.213)
const stringBool = String(false)

console.log(typeof stringNum)

console.log(stringBool)


const num1 = 234
const stringNum1 = String(num1)

console.log(stringNum1)
console.log(typeof stringNum1)