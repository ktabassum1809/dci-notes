const truthyOrNot = ""

if (truthyOrNot) {
    console.log("It's a truthy value!")
} else {
    console.log("It's a falsy value!")
}