import readlineSync from "readline-sync";

const n = readlineSync.questionInt('Number please: ')
console.log(n, typeof(n))