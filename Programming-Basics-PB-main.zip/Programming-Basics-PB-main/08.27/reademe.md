# Workshop 1: more array methods

