# PB - Language 4 - Conditionals:

**Last Week:**

- intro to JS (variables)
- js expressions, operators, Math, string basic methods

**Today:**

- conditionals (if statement)
- block scope

## Exercises:
- [10-PB-language-conditional-statements-basic](https://classroom.github.com/a/MYeEhWRK)
- [11-PB-language-conditional-statements](https://classroom.github.com/a/yJSRptHV)