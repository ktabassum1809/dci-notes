# destructuring arrays and objects:

