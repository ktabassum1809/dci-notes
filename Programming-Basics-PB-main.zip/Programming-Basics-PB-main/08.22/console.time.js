console.time()
for (let i = 0; i < 1000000; i++) {
    console.log(i)
}
console.timeEnd()

console.time()
for (let i = 0; i < 10; i++) {
    console.log(i)
}
console.timeEnd()


