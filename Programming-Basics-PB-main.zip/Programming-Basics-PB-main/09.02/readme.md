# PB Project (individual):

**Deadline:** 12:00 - 10.09.2024
**Presentation:** 13:00 to 16:00 - 10.09.2024

## Projects Links (only one is required but feel free to do more):

- [PB-project-bulls-and-cows](https://classroom.github.com/a/NdiV_pcB)
- [PB-project-shrugman](https://classroom.github.com/a/tXfjWHlS)
- [PB-Calculator](https://classroom.github.com/a/QTXcgikr)
- [PB-pokemon-lite](https://classroom.github.com/a/9tvH0SJp)