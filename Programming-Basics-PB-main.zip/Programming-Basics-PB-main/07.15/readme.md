# PB - Functions - 02 : more functions:

**Last Week:**

- the basics of functions

**Today:**

- functions expressions & arrow functions
- the call stack


## Exercises

- [33-PB-function-1-function-expressions](https://classroom.github.com/a/ij5jeYr-)
- [34-PB-function-1-function-challenges-2](https://classroom.github.com/a/GsNDzsF4)