# PB - language 05 - Logical Operations:

**Yesterday:**

- conditional statements with `If` statement
- block scope 

**Today:**

- logical operators (and &&, or ||, not !)
- ternary operator for mini conditionals

**Exercises**

- [12-PB-program-bookstore](https://classroom.github.com/a/L1buHk1Z)
- [13-PB-program-ternary-operator](https://classroom.github.com/a/Iko91gd4)
- [14-PB-program-ternary-operator-and-logic-basic](https://classroom.github.com/a/vI66N8n8)
- [15-PB-conditionals-fizzbuzz-simple](https://classroom.github.com/a/yHk7RarM)