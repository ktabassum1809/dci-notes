// Let's take 15 minutes of time in groups of 2
// In this time, research "switch statements" and make an example

const expression = "example"

switch (expression) {
    case example1:
        //do whatever
        break
    case example2:
        //do whatever
        break
    default:
        //do whatever
}

// Switch is not as used but sometimes it looks clearer (readability)
// we need to add break inside each case

