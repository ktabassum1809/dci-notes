/**
 * Task 04
 * 
 * Fix the code below to get the expected result in the console
 * 
 */

function double(number) {
    return number * 2;
}

console.log(double(9)); // 18