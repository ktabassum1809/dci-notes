/**
 * Task 01
 * 
 * Fix the code below to get the expected result in the console
 * 
 * Expected output: 7
 */

function add(a, b) {
    return a + b;
}

let result = add(2, 5);

console.log(result);