const products = [
  {
    type: "t-shirt",
    color: "white",
    price: 19.99,
  },
  {
    type: "jeans",
    color: "blue",
    price: 39,
  },
  {
    type: "hat",
    color: "red",
    price: 9,
  },
  {
    type: "t-shirt",
    color: "yellow",
    price: 19,
  },
  {
    type: "t-shirt",
    color: "red",
    price: 29,
  },
  {
    type: "jeans",
    color: "blue",
    price: 19,
  },
  {
    type: "shirt",
    color: "yellow",
    price: 19,
  },
  {
    type: "shoes",
    color: "green",
    price: 49,
  },
  {
    type: "sandals",
    color: "brown",
    price: 12,
  },
  {
    type: "jeans",
    color: "grey",
    price: 22,
  },
  {
    type: "hat",
    color: "red",
    price: 19,
  },
];


/**
 * Use map() so that the variable `productColors` contains
 * only the colors of the products
 * 
 * Expected output:
 * Colors: [ 'white', 'blue', 'red', 'yellow', 'red', 'blue', 'yellow', 'green', 'brown', 'grey', 'red' ]
 * 
 */
const productColors = products.map(product => product.color);
console.log("Product colors:", productColors);
