/**
 * Task 03
 * 
 * Fix the code below so that:
 * - if day is Saturday or Sunday, the output is "YAY!, it's the weekend"
 * - otherwise, the output is "work :("
 */

let day = "Sunday";

let mood = day === "Saturday" || day === "Sunday" ? "YAY!, it's the weekend" : "work :(";

console.log(mood);