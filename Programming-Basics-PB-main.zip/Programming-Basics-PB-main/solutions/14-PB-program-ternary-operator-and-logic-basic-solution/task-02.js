/**
 * Task 2
 * 
 * Fix the code below so that:
 * 
 * - if cartTotal is larger than or equal to 50, shippingCosts is 0
 * - if cartTotal is less than 50, shippingCosts is 9.99 
 *
 */

let cartTotal = 50;

let shippingCosts = cartTotal >= 50 ? 0 : 9.99;

console.log(
  `With a cart of ${cartTotal}€ the shipping costs amount to ${shippingCosts}€`
);
