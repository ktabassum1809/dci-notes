/**
 * Task 08
 * 
 * Fix the code below so that:
 * 
 * - if the user is not logged in, the right message is printed
 */

let isLoggedIn = false;

let message = !isLoggedIn ? "Please login before proceeding." : "Welcome!";

console.log(message);
