/**
 * Task 1
 * 
 * Fix the code below so that if hour is larger than or equal to 9,
 * the message "It's late, wake up!" is printed to the console. Otherwise, 
 * if it's smaller than 9, the message "Go back to bed is printed"
 */
let hour = 9;
let action = hour >= 9 ? "It's late, wake up!" : "Go back to bed";

console.log(action);
