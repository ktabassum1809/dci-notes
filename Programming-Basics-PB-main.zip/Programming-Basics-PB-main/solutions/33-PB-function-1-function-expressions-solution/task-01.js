/*
Task 01

Rewrite the function declaration below as a one line arrow 
function expression.
*/

const add = (a, b) => a + b;

console.log(add(1, 2));
console.log(add(6, 3));
console.log(add(4, 10));