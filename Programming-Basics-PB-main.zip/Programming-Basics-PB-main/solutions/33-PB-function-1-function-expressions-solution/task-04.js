/*
Task 04
  
Rewrite the arrow function below as a standard function declaration
*/

function double(number) {
  return number * 2;
}

console.log(double(9)); // 18
