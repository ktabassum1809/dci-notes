/*
Task 4
*/

let money = 10;
let gift = Math.floor(money / 3);
money = money % 3;

console.log(gift);
console.log(money);