/*
Task 1

*/

let total = 0;

let tShirtPrice = 9;
let shoesPrice = 29;
let hatPrice = 19;

total = tShirtPrice + shoesPrice + hatPrice;

console.log("The total is: ", total);