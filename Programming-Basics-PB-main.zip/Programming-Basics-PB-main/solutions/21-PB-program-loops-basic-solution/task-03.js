/**
 * Complete the code below so that output will be a string with 5 +
 * 
 * Expected output: +++++
 */

let output = "";

for (let i = 0; i < 5; i++) {
  output += "+";
}

console.log(output);
