/**
 * Task 04
 * 
 * Complete the code below so that output will be the string: 12345
 * 
 * Expected output: 12345
 */

let output = "";

for (let i = 1; i <= 5; i++) {
    output += i;
}

console.log(output);