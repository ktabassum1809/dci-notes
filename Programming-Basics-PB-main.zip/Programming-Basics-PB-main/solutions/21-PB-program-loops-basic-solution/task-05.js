/**
 * Task 05
 * 
 * Complete the code below so that the numbers from 0 down to -10 are printed 
 * to the console 
 */

for (i = 0; i >= -10; i--) {
    console.log(i);
}