/**
 * Task 02
 * 
 * Complete the code below so that it prints the numbers from 100 to 50
 */

for (let i = 100; i >= 50; i--) {
  console.log(i);
}
