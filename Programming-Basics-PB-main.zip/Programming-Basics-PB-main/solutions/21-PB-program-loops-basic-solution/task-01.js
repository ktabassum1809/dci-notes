/**
 * Task 01
 * 
 * Fix the code below so that it prints the numbers from 0 to 10
 * 
 */

for (let i = 0; i < 10; i++) {
    console.log(i);
}