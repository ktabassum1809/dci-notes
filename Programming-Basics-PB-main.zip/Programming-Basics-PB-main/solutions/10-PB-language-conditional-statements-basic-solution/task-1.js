/**
 * Task 1
 * 
 * Complete the code below to print one of the 2 messages:
 * 
 * - if hour is greater than 8, print `Get up`
 * - otherwise, print `Go back to sleep`
 */

const hour = 10;

if () {
  console.log("Get up");
} else {
  console.log("Go back to sleep");
}
