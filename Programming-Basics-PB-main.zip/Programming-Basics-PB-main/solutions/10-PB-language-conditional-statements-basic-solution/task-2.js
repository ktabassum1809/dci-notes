/**
 * Task 2
 * 
 * Complete the code below so that the message `Play videogames`
 * is printed only if the boolean hasFinishedHomework is true
 * 
 */

const hasFinishedHomework = false;

if (hasFinishedHomework === false) {
  console.log("Keep studying");
}
console.log("Play videogames");