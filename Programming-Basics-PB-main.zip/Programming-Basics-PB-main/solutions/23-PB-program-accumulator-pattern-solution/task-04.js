/**
 * Task 4
 * 
 * Use a loop to create an array containing the numbers from 0 to 100, then print
 * the whole array to the console
 * 
 * Expected output:
 * [0, 1, 2, 3, 4, 5, 6, ..., 98, 99, 100]
 * 
 */

const result = [];

for (let i = 0; i <= 100; i++) {
    result.push(i);
}

console.log(result);