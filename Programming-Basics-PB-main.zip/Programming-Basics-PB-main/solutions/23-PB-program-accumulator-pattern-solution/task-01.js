/**
 * Task 1
 * 
 * Use a loop to calculate the sum of the first 10 numbers and print the result
 * to the console
 * 
 */
let sum = 0;

for (let i = 0; i <= 10; i++) {
  sum += i;
}

console.log(`The sum of the first 10 numbers is ${sum}`);
