/**
 * Task 4
 * Breakfast options
 */

let isMilkAvailable = true;
let isBreadAvailable = true;
let isAppleAvailable = true;

if (isBreadAvailable === true) {
  console.log("I'll have a sandwich");
} else if (isMilkAvailable === true) {
  console.log("Some milk with cereals will be ok");
} else if (isAppleAvailable) {
  console.log("Ok, I guess I'll just eat an apple");
} else {
  console.log("I'll have breakfast outside!");
}
