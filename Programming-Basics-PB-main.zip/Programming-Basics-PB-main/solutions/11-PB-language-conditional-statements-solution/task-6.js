let x = 5;
let y = 7;

if (x > y) {
  console.log("x is greater than y");
} else if (y > x) {
  console.log("y is greater than x");
} else {
  console.log("x and y are equal");
}
