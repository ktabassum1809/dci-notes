let n = 5;

if (n % 2 === 0) {
  console.log(`${n} is an even number`);
} else {
  console.log(`${n} is an odd number`);
}
