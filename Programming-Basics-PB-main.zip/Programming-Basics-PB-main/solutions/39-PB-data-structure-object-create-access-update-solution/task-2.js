// Task 2

const person = {
    firstName: "Martha",
    lastName: "Martin",
    age: 27
};

// Increase the `age` by 1:
// write your code here

person.age++;

// alternative solutions:
// person.age += 1;
// person.age = person.age + 1;

console.log(person);
