// Task 1

const book = {
    title: "A Smarter Way to Learn JavaScript",
    author: "Mark Myers",
    price: 19.95,
    read: false
};


// change the `read` property from false to true

// write your code here:

book.read = true;

console.log(book);
