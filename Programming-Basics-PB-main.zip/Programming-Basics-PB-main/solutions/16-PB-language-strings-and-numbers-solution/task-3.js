let breakfastPrice = "12€";
let lunchPrice = "18.71€";
let dinnerPrice = "43.63€";

// Calculate the tip for each price
let breakfastTotal = Math.ceil(parseFloat(breakfastPrice) * 1.1);
let lunchTotal = Math.ceil(parseFloat(lunchPrice) * 1.1);
let dinnerTotal = Math.ceil(parseFloat(dinnerPrice) * 1.1);
