/**
 * Fix the code below so that it works with the let keyword instead of var.
 * 
 * - The variable should initially be declared with the value of 5 
 * - on a separate line, assign the value 7 to the variable
 * 
 * The output in the console should then be 7.
 * 
 */

let x = 5;
x = 7;

// don't change this
console.log(x);