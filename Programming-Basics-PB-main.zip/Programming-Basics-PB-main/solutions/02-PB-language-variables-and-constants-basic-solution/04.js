/**
 * Fix the code below so that the first console.log() outputs "Hello Jude" 
 * and the second one "Hey Jude"
 */

const firstName = "Jude";
let greeting = "Hello";

console.log(greeting, firstName); // Hello Jude

greeting = "Hey";

console.log(greeting, firstName); // Hey Jude
