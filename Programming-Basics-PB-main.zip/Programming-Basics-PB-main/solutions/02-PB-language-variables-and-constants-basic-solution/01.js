/**
 * Complete the code below so that in the console we see the number 11
 */

const x = 11;

// don't change this
console.log(x);