/**
 * Right now the output in the console is "true".
 * 
 * Change the value of the variable isLoggedIn and the code inside the
 * console.log() so that the output is "boolean"
 */

let isLoggedIn = true;

console.log(typeof isLoggedIn);
