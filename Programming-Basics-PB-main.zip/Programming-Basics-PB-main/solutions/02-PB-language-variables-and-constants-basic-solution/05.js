/**
 * Fix the code below so that the output in the console is 8
 * 
 */

let x = 8;

// don't change this
console.log(x);