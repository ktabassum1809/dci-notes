/**
 * Fix the code below so that the output in the console is the number 5 
 */

let x;
x = 5;

// don't change this
console.log(x);