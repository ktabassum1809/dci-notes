/**
 * Fix the code below so that the output in the console is the string 'hello'
 */

const greeting = "hello";

// don't change this
console.log(greeting);
