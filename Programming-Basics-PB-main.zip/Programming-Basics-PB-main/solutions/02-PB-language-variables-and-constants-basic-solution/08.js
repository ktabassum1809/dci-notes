/**
 * Right now the output in the console is "number". 
 * 
 * Change the code below so that the output is "string".
 */

const x = "2";

// don't change this
console.log(typeof x)