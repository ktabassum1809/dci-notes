/**
 * Task 1
 * 
 * Modify the code below so that the first and last character of the string
 * are printed to the console
 * 
 * Expected output:
 * hd
 */


const string = "hello world";
const firstCharacter = string[0];
const lastCharacter = string[string.length - 1];

// don't change this
console.log(firstCharacter + lastCharacter)