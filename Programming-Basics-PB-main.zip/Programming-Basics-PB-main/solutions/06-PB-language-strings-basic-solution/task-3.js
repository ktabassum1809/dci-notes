/**
 * Task 3 
 * 
 * Change the code below so that the word "help" is printed to the
 * console without any space between the letters
 * 
 * Expected output:
 * help
 */

const letter1 = "h";
const letter2 = "e";
const letter3 = "l";
const letter4 = "p";

console.log(letter1 + letter2 + letter3 + letter4);