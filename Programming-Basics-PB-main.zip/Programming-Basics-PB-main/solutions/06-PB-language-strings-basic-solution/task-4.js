/**
 * Task 4 
 * 
 * Modify the `poem` variable so that the poem appears on 4 separate lines
 * 
 * Expected output:
 * 
 * Roses are red
 * Violets are blue
 * I am a programmer
 * And so are you!
 */


const poem = "Roses are red\nViolets are blue\nI am a programmer\nAnd so are you!";

console.log(poem);