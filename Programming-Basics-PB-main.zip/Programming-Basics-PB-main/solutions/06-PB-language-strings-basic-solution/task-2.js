/**
 * Task 2
 * 
 * Change the code below so that the ! is printed to the console
 * 
 * Expected output:
 * !
 * 
 */

const string = "abc!def";

console.log(string[string.length - 4]);