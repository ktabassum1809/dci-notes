/**
 * Task 08
 * 
 * Complete the code below so that the output in the console will be a string like the one below:
 * 
 * "1-2-3-4-5"
 * 
 */

const array = [1, 2, 3, 4, 5];

console.log(array.join("-"));
