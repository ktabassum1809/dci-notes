/**
 * Task 03
 * 
 * Complete the code below so that:
 * 
 * - the first console.log() outputs London
 * - the second console.log() outputs Berlin
 * 
 */

const cities = ["Berlin", "Leipzig", "London", "Rome", "Tokyo"];


console.log(cities[2]); // London
console.log(cities[0]); // Berlin 