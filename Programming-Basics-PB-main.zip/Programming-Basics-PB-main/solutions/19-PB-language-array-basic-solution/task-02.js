/**
 * Task 02
 * 
 * Complete the code below so that:
 * 
 * - the output of the first console.log() is Julia
 * - the output of the second console.log() is Tom
 * - the output of the third console.log() is Gina
 * 
 */

const people = ["Julia", "Tom", "Gina"];

console.log(people[0]); // Julia
console.log(people[1]); // Tom
console.log(people[2]); // Gina