/*
Task 9

Complete the code below so that the output in the console is 
an array like below:

Expected output:

["12", "35", "05"]
*/


let time = "12:35:05";

console.log(time.split(":")); // ["12", "35", "05"]
