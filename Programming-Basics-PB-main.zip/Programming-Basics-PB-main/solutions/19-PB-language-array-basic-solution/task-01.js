/**
 * Task 1
 * 
 * Fix the code below so that the array animals is printed to the console
 */

const animals = ["giraffe", "cat", "dog", "mouse", "koala"];

console.log(animals);