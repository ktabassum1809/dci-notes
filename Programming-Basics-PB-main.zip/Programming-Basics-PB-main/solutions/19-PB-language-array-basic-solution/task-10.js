/**
 * Task 10
 * 
 * Complete the code below so that the last item of the array is 
 * printed to the console
 * 
 * Expected output:
 * My favourite color is green
 */

const colors = ["red", "blue", "yellow", "brown", "green"];
const favouriteColor = colors[colors.length - 1];

console.log(`My favourite color is ${favouriteColor}`)