/**
 * Task 5
 * 
 * Fix the code below by replacing `???` with the right operator so that every 
 * console.log() prints `true`
 */

const apples = 8;
const oranges = 6;

console.log("1.", apples === 8);
console.log("2.", apples > oranges);
console.log("3.", oranges !== "6");
console.log("4.", oranges < apples);
console.log("5.", apples < 10);
console.log("6.", apples + oranges > 10);
console.log("7.", apples - oranges === 2);
console.log("8.", apples + oranges <= 14);
console.log("9.", apples + oranges === oranges + apples);
console.log("10.", apples !== oranges);
