/**
 * Task 1
 * 
 * You ordered a coffee, a sandwich and cake.
 * Modify the code below so that `total` is equal to the total amount to pay for 
 * 
 * Expected output:
 * The total to pay is 12€
 */


const coffeePrice = 2.5;
const sandwichPrice = 4.5;
const cakePrice = 5;

const total = coffeePrice + sandwichPrice + cakePrice;

console.log(`The total to pay is ${total}€`)