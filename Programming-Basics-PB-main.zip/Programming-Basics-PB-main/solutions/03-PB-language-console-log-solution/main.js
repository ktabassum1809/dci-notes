console.log("Task 1");
console.log(2);


console.log("Task 2");
console.log("hello");

console.log("Task 3");
let number = 5;
console.log(number);

console.log("Task 4");
console.log(typeof number);

console.log("Task 5");
console.log(false);

console.log("Task 6");
const firstName = "John";
const lastName = "Smith";
const city = "Berlin";
const favouriteBand = "Green Day";
const favouriteMovie = "12 Angry Men";
const favouriteBook = "The Handmaid's Tale";

console.log(firstName);
console.log(lastName);
console.log(city);
console.log(favouriteBand);
console.log(favouriteMovie);
console.log(favouriteBook);

console.log(
  firstName,
  lastName,
  city,
  favouriteBand,
  favouriteMovie,
  favouriteBook
);