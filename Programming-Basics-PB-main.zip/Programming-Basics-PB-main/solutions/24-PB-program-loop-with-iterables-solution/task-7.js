/*
 Task 7
 */

const sentence = "I'm something of a developer myself";

for (let i = sentence.length - 1; i >= 0; i--) {
  console.log(sentence[i]);
}
