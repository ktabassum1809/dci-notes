/*
 Task 6
 */

const letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i"];

for (let i = 0; i < letters.length; i++) {
  if (i % 2 === 0) {
    console.log(letters[i]);
  }
}
