/*
 Task 2
 */

const animals = ["cat", "dog", "bird", "koala", "giraffe"];

for (let i = 0; i < animals.length; i++) {
  console.log(animals[i]);
}
