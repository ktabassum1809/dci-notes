/*
 Task 9
 */

const prices = [9.99, 12.5, 120, 748, 2.99, 500];
const result = [];

for (let i = 0; i < prices.length; i++) {
  result.push(prices[i] + "€");
}

console.log(result);
