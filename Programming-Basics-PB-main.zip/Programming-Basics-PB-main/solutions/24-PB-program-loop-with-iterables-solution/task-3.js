/*
 Task 3
 */


const colors = ["green", "pink", "yellow", "red", "violet"];

for (let i = 0; i < colors.length; i++) {
    console.log(`${i + 1}. ${colors[i]}`)
}