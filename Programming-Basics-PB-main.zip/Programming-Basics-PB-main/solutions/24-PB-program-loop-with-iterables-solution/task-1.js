/*
 Task 1
 */

const string = "hello";

for (let i = 0; i < string.length; i++) {
    console.log(string[i]);
}

