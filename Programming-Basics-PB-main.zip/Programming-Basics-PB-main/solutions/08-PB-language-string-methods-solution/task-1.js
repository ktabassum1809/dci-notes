// Task 1

let text = "hello world!";
let upperCaseText = text.toUpperCase();

console.log(text);
console.log(upperCaseText);

let animal = "ELEPHANT";
let lowerCaseAnimal = animal.toLowerCase();

console.log(animal);
console.log(lowerCaseAnimal);
