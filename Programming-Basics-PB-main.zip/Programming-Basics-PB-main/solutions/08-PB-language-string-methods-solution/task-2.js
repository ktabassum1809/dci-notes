// Task 2

let date = "21/06/1983";
let day = date.slice(0, 2);
let month = date.slice(3, 5);
let year = date.slice(6);

console.log("Day:", day); 
console.log("Month:", month);
console.log("Year:", year);