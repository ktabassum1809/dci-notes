# Higher-order functions and callback functions:

### Higher-order function:

is a function that either **returns** a function or takes a function (callback) as a **parameter**

### Callback function:

is a function that is passed to another function as an argument