# Advanced Array methods - 2:

**Last Week:**

- Advanced array methods 1 (map, forEach, filter)

**Today:**

- Advanced array methods 2 (reduce, sort)
