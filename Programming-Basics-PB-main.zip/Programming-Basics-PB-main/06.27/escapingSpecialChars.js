// Expected output: 'I'm Eloy'

const myName = 'I\'m Eloy'
console.log(myName)

// Expected output: "Yes, yes, you are so good that you put the "pro" in "programming""

const phrase = "Yes, yes, you are so good that you put the \"pro\" in \"programming\""
console.log(phrase)

// Expected output
// Me: hello, world
// World: hello, Eloy 

const twoPhrases = "Me: hello, world\nWorld: Hello, Eloy"
console.log(twoPhrases)