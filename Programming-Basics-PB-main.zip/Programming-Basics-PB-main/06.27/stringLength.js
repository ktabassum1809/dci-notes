const firstName = "Nausica"
const lastName = "Castriota"
const empty = ""
const space = " "

console.log("firstName length", firstName.length)
console.log("lastName length", lastName.length)
console.log("empty length", empty.length)
console.log("space length", space.length)