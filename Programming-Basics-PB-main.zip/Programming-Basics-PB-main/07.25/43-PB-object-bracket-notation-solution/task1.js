const product = {
    type: "t-shirt",
    color: "green",
    brand: "Awesome Tees",
    price: 19.99,
  };

  let key = "brand"
  console.log(product[key]) // "Awesome Tees"
  console.log(product["brand"])
  console.log(product.brand)