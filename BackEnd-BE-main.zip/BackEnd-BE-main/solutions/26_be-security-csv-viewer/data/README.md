# Data sources

- Emissions data https://catalog.data.gov/dataset/supply-chain-greenhouse-gas-emission-factors-v1-2-by-naics-6
- Population data https://data.worldbank.org/indicator/SP.POP.TOTL?locations=DE (edited for simplicity)
