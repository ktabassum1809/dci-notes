#!/bin/bash

curl http://localhost:7771/data -X POST --data 'species=Lupus lupus'; echo