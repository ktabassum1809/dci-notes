#!/bin/bash

curl http://localhost:7771/data; echo