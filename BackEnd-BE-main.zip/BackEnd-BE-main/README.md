# Backend-BE

## Server:

- [24.11.18](24.11.18): Server-intro
- [24.11.19](24.11.19): Post requests, fs
- [24.11.21](24.11.21): CRUD,PUT,PATCH,DELETE
- [24.11.25](24.11.25): Middlewares
- [24.11.27](24.11.27): Express.Router
- [24.11.28](24.11.28): Error Handling
- [24.12.02](24.12.02): Environment variables, deployment
- [24.12.03](24.12.03): database-intro
- [24.12.04](24.12.04): mongDB continued
- [24.12.05](24.12.05): Atlas,Compass
- [24.12.09](24.12.09): Mongoose intro
- [24.12.11](24.12.11): Mongoose continued
- [25.12.07](25.12.07): Schema types, subdocuments
- [25.01.08](25.01.08): Mongoose pagination
- [25.01.13](25.01.13): Intro to security
- [25.01.14](25.01.14): Express-validator
- [25.01.15](25.01.15): Encryption, Hashing
- [25.01.20](25.01.20): Roles, Cookies
- [25.01.21](25.01.21): File-uploads (multer)
- [25.01.27](25.01.27): Nodemailer
- [25.01.28](25.01.28): Livecoding - project

