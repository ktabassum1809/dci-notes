
export const price=(req,res,next)=>{

console.log('this is the price middleware')
next()
}