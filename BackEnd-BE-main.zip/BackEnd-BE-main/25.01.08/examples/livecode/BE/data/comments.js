export default [
  {
    
    "content":"firstComment"
   
},
{
 
  "content":"secondComment"
 
},
{
 
  "content":"thirdComment"
 
},
{
 
  "content":"fourthComment"
 
},
{
 
  "content":"fifthComment"
 
},
{
 
  "content":"sixthComment"
 
},
{
  
  "content":"seventhComment"
 
},
{
  
  "content":"eighthComment"
 
},
{
  
  "content":"ninthComment"
 
},
{
 
  "content":"tenthComment"
 
},
{
  
  "content":"eleventhComment"
 
},
    
  ];